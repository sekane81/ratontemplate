<?php
// since version 1.0

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

// load the shortcodes
ts_essentials_load_file( 'includes/shortcodes/shortcodes.class' );
ts_essentials_load_file( 'includes/shortcodes/shortcodes' );