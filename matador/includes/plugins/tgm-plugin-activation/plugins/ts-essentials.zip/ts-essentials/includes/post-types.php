<?php
// since version 1.0

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

// load some custom post types
ts_essentials_load_file( 'includes/post-types/mega-menu' );
ts_essentials_load_file( 'includes/post-types/portfolio' );