<?php

/**
 * SMOF Option filters
 *
 * @since       1.0
 * @author      Original credit to Jonah Dahlquist
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Filter URLs from uploaded media fields and replaces them with keywords.
 * This is to keep from storing the site URL in the database to make
 * migrations easier.
 * 
 * @since 1.4.0
 * @param $data Options array
 * @return array
 */
function of_filter_save_media_upload($data) {
    $data = (is_array($data)) ? $data : array();
    foreach ($data as $key => $value) {
        if (is_string($value)) {
            $data[$key] = str_replace(
                array(
                    '[site_url]', 
                    '[site_url_secure]',
                    '[template_directory]',
                ),
                array(
                    site_url('', 'http'),
                    site_url('', 'https'),
                    get_template_directory_uri(),
                ),
                $value
            );
        }
    }

    return $data;
}
add_filter('of_options_before_save', 'of_filter_save_media_upload');

/**
 * Filter URLs from uploaded media fields and replaces the site URL keywords
 * with the actual site URL.
 * 
 * @since 1.4.0
 * @param $data Options array
 * @return array
 */
function of_filter_load_media_upload($data) {
    $data = (is_array($data)) ? $data : array();
    foreach ($data as $key => $value) {
        if (is_string($value)) {
            $data[$key] = str_replace(
                array(
                    '[site_url]', 
                    '[site_url_secure]',
                    '[template_directory]',
                ),
                array(
                    site_url('', 'http'),
                    site_url('', 'https'),
                    get_template_directory_uri(),
                ),
                $value
            );
        }
    }

    return $data;
}
add_filter('of_options_after_load', 'of_filter_load_media_upload');
